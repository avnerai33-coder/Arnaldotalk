Write-Host "==============================================" -ForegroundColor Cyan
Write-Host "     Building Arnaldo Talk Single-File EXE" -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Cyan

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

Write-Host "==> Publishing Windows x64 Single-File Executable..." -ForegroundColor Yellow
dotnet publish ArnaldoTalk\ArnaldoTalk.csproj `
    -c Release `
    -r win-x64 `
    --self-contained false `
    -p:PublishSingleFile=true `
    -o dist

Write-Host ""
Write-Host "==> Build complete! Output located at:" -ForegroundColor Green
Write-Host "    $ScriptDir\dist\ArnaldoTalk.exe" -ForegroundColor White
Write-Host ""

