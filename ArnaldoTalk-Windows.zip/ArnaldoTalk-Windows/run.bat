@echo off
echo ==============================================
echo       Launching Arnaldo Talk for Windows
echo ==============================================
echo Hotkey: Ctrl + Win + Space
echo.

where dotnet >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [.NET Not Found] Please install .NET 8 or 9 SDK:
    echo   winget install Microsoft.DotNet.SDK.8
    pause
    exit /b 1
)

cd /d "%~dp0"
dotnet run --project ArnaldoTalk\ArnaldoTalk.csproj -c Release
pause

