using System;
using System.Collections.Generic;
using System.Linq;

namespace ArnaldoTalk.Core
{
    public record KeyItem(uint Vk, string Name, string Symbol);
    public record TickableButtonItem(string Id, string Label, string Badge, bool IsModifier, uint Modifier = 0, uint Vk = 0);

    public static class KeyHelper
    {
        public const uint MOD_ALT = 0x0001;
        public const uint MOD_CONTROL = 0x0002;
        public const uint MOD_SHIFT = 0x0004;
        public const uint MOD_WIN = 0x0008;

        public const uint MODIFIER_ONLY_VK = 0xFFFF;

        public static readonly List<TickableButtonItem> TickableButtons = new()
        {
            new TickableButtonItem("alt", "Alt Key", "Alt", true, MOD_ALT),
            new TickableButtonItem("ctrl", "Ctrl Key", "Ctrl", true, MOD_CONTROL),
            new TickableButtonItem("win", "Win Key", "Win", true, MOD_WIN),
            new TickableButtonItem("shift", "Shift Key", "Shift", true, MOD_SHIFT),
            new TickableButtonItem("space", "Spacebar", "Space", false, 0, 0x20),
            new TickableButtonItem("enter", "Enter", "Enter", false, 0, 0x0D),
            new TickableButtonItem("tab", "Tab", "Tab", false, 0, 0x09),
            new TickableButtonItem("esc", "Escape", "Esc", false, 0, 0x1B),
            new TickableButtonItem("k", "K Key", "K", false, 0, 0x4B),
            new TickableButtonItem("d", "D Key", "D", false, 0, 0x44),
            new TickableButtonItem("f5", "F5 Key", "F5", false, 0, 0x74)
        };

        public static readonly List<KeyItem> PopularKeys = new()
        {
            new KeyItem(0x20, "Spacebar", "Space"),
            new KeyItem(0x0D, "Enter / Return", "Enter"),
            new KeyItem(0x09, "Tab", "Tab"),
            new KeyItem(0x1B, "Escape", "Esc"),
            new KeyItem(0x08, "Backspace", "Backspace"),
            new KeyItem(0x74, "F5 Key", "F5"),
            new KeyItem(0x75, "F6 Key", "F6"),
            new KeyItem(0x70, "F1 Key", "F1"),
            new KeyItem(0x71, "F2 Key", "F2"),
            new KeyItem(0x72, "F3 Key", "F3"),
            new KeyItem(0x73, "F4 Key", "F4"),
            new KeyItem(0x76, "F7 Key", "F7"),
            new KeyItem(0x77, "F8 Key", "F8"),
            new KeyItem(0x78, "F9 Key", "F9"),
            new KeyItem(0x79, "F10 Key", "F10"),
            new KeyItem(0x7A, "F11 Key", "F11"),
            new KeyItem(0x7B, "F12 Key", "F12")
        };

        public static readonly List<KeyItem> LetterKeys = Enumerable.Range(0x41, 26)
            .Select(c => new KeyItem((uint)c, $"Letter {(char)c}", $"{(char)c}"))
            .ToList();

        public static readonly List<KeyItem> NumberKeys = Enumerable.Range(0x30, 10)
            .Select(c => new KeyItem((uint)c, $"Number {(char)c}", $"{(char)c}"))
            .ToList();

        public static List<KeyItem> AllSelectableKeys => PopularKeys.Concat(LetterKeys).Concat(NumberKeys).ToList();

        public static string GetKeyName(uint vk)
        {
            if (vk == MODIFIER_ONLY_VK) return "";
            var match = AllSelectableKeys.FirstOrDefault(k => k.Vk == vk);
            return match != null ? match.Symbol : $"VK_0x{vk:X2}";
        }

        public static string FormatShortcut(uint modifiers, uint vk)
        {
            var parts = new List<string>();
            if ((modifiers & MOD_CONTROL) != 0) parts.Add("Ctrl");
            if ((modifiers & MOD_ALT) != 0) parts.Add("Alt");
            if ((modifiers & MOD_WIN) != 0) parts.Add("Win");
            if ((modifiers & MOD_SHIFT) != 0) parts.Add("Shift");

            if (vk == MODIFIER_ONLY_VK)
            {
                return parts.Count > 0 ? string.Join(" + ", parts) : "No Shortcut";
            }

            string key = GetKeyName(vk);
            if (!string.IsNullOrEmpty(key))
            {
                parts.Add(key);
            }
            return string.Join(" + ", parts);
        }

        public static List<string> GetModifierBadges(uint modifiers)
        {
            var parts = new List<string>();
            if ((modifiers & MOD_CONTROL) != 0) parts.Add("Ctrl");
            if ((modifiers & MOD_ALT) != 0) parts.Add("Alt");
            if ((modifiers & MOD_WIN) != 0) parts.Add("Win");
            if ((modifiers & MOD_SHIFT) != 0) parts.Add("Shift");
            return parts;
        }

        public static bool ContainsHebrew(string text)
        {
            if (string.IsNullOrEmpty(text)) return false;
            return text.Any(c => c >= 0x0590 && c <= 0x05FF);
        }
    }
}
