using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace ArnaldoTalk.Core
{
    public class TextEnhancer
    {
        private static readonly Lazy<TextEnhancer> _instance = new(() => new TextEnhancer());
        public static TextEnhancer Shared => _instance.Value;

        private readonly string[] _fillerPatterns = new[]
        {
            @"\b[Uu]m[,.]?\s*",
            @"\b[Uu]h[,.]?\s*",
            @"\b[Ee]rm[,.]?\s*",
            @"\b[Aa]h[,.]?\s*",
            @"\b[Ll]ike,\s*",
            @"\b[Yy]ou know,\s*"
        };

        private readonly (string pattern, string replacement)[] _spokenPunctuationMap = new[]
        {
            (@"\b(new paragraph|next paragraph)\b", "\n\n"),
            (@"\b(new line|newline)\b", "\n"),
            (@"\b(bullet point|bullet)\b", "\n• "),
            (@"\b(period|full stop)\b", "."),
            (@"\b(comma)\b", ","),
            (@"\b(question mark)\b", "?"),
            (@"\b(exclamation mark|exclamation point)\b", "!"),
            (@"\b(colon)\b", ":"),
            (@"\b(semicolon)\b", ";"),
            (@"\b(ellipsis|dot dot dot)\b", "..."),
            (@"\b(dash|hyphen)\b", " - "),
            (@"\b(open parenthesis|open paren)\b", "("),
            (@"\b(close parenthesis|close paren)\b", ")"),
            (@"\b(open quote|open quotation)\b", "\""),
            (@"\b(close quote|end quote|unquote)\b", "\""),

            // Hebrew Spoken Punctuation (עברית)
            (@"(?<=^|\s)(פסקה חדשה)(?=\s|$)", "\n\n"),
            (@"(?<=^|\s)(שורה חדשה)(?=\s|$)", "\n"),
            (@"(?<=^|\s)(נקודה)(?=\s|$)", "."),
            (@"(?<=^|\s)(פסיק)(?=\s|$)", ","),
            (@"(?<=^|\s)(סימן שאלה)(?=\s|$)", "?"),
            (@"(?<=^|\s)(סימן קריאה)(?=\s|$)", "!"),
            (@"(?<=^|\s)(נקודתיים)(?=\s|$)", ":"),
            (@"(?<=^|\s)(מקף)(?=\s|$)", " - "),
            (@"(?<=^|\s)(סוגריים פתוחים)(?=\s|$)", "("),
            (@"(?<=^|\s)(סוגריים סגורים)(?=\s|$)", ")"),
            (@"(?<=^|\s)(מרכאות)(?=\s|$)", "\"")
        };

        private TextEnhancer() { }

        public string CleanTranscript(
            string text,
            bool spokenPunctuation = true,
            bool selfCorrection = true,
            bool autoPunctuation = true,
            bool grammarCorrection = true)
        {
            if (string.IsNullOrWhiteSpace(text)) return string.Empty;

            string processed = text.Trim();

            // 1. Smart Self-Correction ("wait no", "actually", "scratch that")
            if (selfCorrection)
            {
                processed = ApplySelfCorrections(processed);
            }

            // 2. Remove filler words
            foreach (var pattern in _fillerPatterns)
            {
                processed = Regex.Replace(processed, pattern, string.Empty);
            }

            // 3. Spoken Punctuation and Structural Commands
            if (spokenPunctuation)
            {
                foreach (var (pattern, replacement) in _spokenPunctuationMap)
                {
                    processed = Regex.Replace(processed, pattern, replacement, RegexOptions.IgnoreCase);
                }
            }

            // 4. Grammar corrections (contractions, pronoun I, deduplication, numbers)
            if (grammarCorrection)
            {
                processed = ApplyGrammarCorrections(processed);
            }

            // 5. Normalize spacing around punctuation and structural breaks
            processed = Regex.Replace(processed, @"\s+([,.\?!;:])", "$1");
            processed = Regex.Replace(processed, @"\(\s+", "(");
            processed = Regex.Replace(processed, @"\s+\)", ")");
            processed = Regex.Replace(processed, @"[ \t]*\n[\s]*•[ \t]*", "\n• ");
            processed = Regex.Replace(processed, @"[ \t]*\n[ \t]*", "\n");
            processed = Regex.Replace(processed, @"\n{3,}", "\n\n");
            processed = Regex.Replace(processed, @"[ \t]{2,}", " ");
            processed = Regex.Replace(processed, @"^[,.\?!;:]+\s*", string.Empty);

            // 6. Apply custom vocabulary replacements
            var vocab = VocabularyManager.Shared.GetVocabulary();
            foreach (var kvp in vocab)
            {
                string regexPattern = $@"\b{Regex.Escape(kvp.Key)}\b";
                processed = Regex.Replace(processed, regexPattern, kvp.Value, RegexOptions.IgnoreCase);
            }

            // 7. Sentence boundary and newline capitalization
            processed = CapitalizeSentenceBoundaries(processed);

            // 8. Auto-punctuation (Ensure sentence ends with period or question mark)
            if (autoPunctuation)
            {
                processed = RestoreAutoPunctuation(processed);
            }

            return processed.Trim();
        }

        private string ApplyGrammarCorrections(string text)
        {
            string s = text;

            // Missing apostrophes in common English contractions
            s = Regex.Replace(s, @"\bdont\b", "don't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bcant\b", "can't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bwont\b", "won't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bdidnt\b", "didn't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bisnt\b", "isn't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\barent\b", "aren't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bwasnt\b", "wasn't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bwerent\b", "weren't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bhasnt\b", "hasn't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bhavent\b", "haven't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bhadnt\b", "hadn't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bcouldnt\b", "couldn't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bshouldnt\b", "shouldn't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bwouldnt\b", "wouldn't", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bthats\b", "that's", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bwhats\b", "what's", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\btheres\b", "there's", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\blets\b", "let's", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\byoure\b", "you're", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\btheyre\b", "they're", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bwere\b\s+(?:going|leaving|ready|eating)", "we're ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bive\b", "I've", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bid\b\s+(?:like|love|rather|prefer)", "I'd ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bill\b\s+(?:be|go|see|do|call)", "I'll ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bim\b", "I'm", RegexOptions.IgnoreCase);

            // Standalone pronoun 'i' capitalization
            s = Regex.Replace(s, @"(?<=^|\s)i(?=[,\.\?!;\s]|$)", "I");

            // Word stutter deduplication (e.g. "the the" -> "the")
            s = Regex.Replace(s, @"\b([A-Za-z]{2,})\s+\1\b", "$1", RegexOptions.IgnoreCase);

            // Spoken numbers and percentages
            s = Regex.Replace(s, @"\btwenty[- ]five percent\b", "25%", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bfifty percent\b", "50%", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bseventy[- ]five percent\b", "75%", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bten percent\b", "10%", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\b(\d+)\s+percent\b", "$1%", RegexOptions.IgnoreCase);

            // Spoken currency
            s = Regex.Replace(s, @"\bfive dollars?\b", "$5", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bten dollars?\b", "$10", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\btwenty dollars?\b", "$20", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bone hundred dollars?\b", "$100", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\b(\d+)\s+dollars?\b", "$$$1", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\b(\d+)\s+euros?\b", "€$1", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\b(\d+)\s+pounds?\b", "£$1", RegexOptions.IgnoreCase);

            // Hebrew transition comma
            s = Regex.Replace(s, @"(?<=^|\s)(אבל|אולם|לכן|לפיכך|בנוסף|יתרה מזו|למעשה)(?=\s)", "$1,");

            // Hebrew Typographical & Letter Fixes (final letters at end of words)
            s = Regex.Replace(s, @"כ(?=[\s,\.\?!;:""'\)]|$)", "ך");
            s = Regex.Replace(s, @"מ(?=[\s,\.\?!;:""'\)]|$)", "ם");
            s = Regex.Replace(s, @"נ(?=[\s,\.\?!;:""'\)]|$)", "ן");
            s = Regex.Replace(s, @"פ(?=[\s,\.\?!;:""'\)]|$)", "ף");
            s = Regex.Replace(s, @"צ(?=[\s,\.\?!;:""'\)]|$)", "ץ");

            return s;
        }

        private string RestoreAutoPunctuation(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return text;
            string trimmed = text.Trim();

            char last = trimmed[^1];
            if (last == '.' || last == '?' || last == '!' || last == ':' || last == ';')
            {
                return trimmed;
            }

            // Do not force periods onto bullet-pointed lists
            if (trimmed.Contains("•"))
            {
                return trimmed;
            }

            // Extract last sentence to determine question status
            var sentences = trimmed.Split(new[] { '.', '!', '?', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            string lastSentence = sentences.Length > 0 ? sentences[^1].Trim() : trimmed;
            string lowerLast = lastSentence.ToLowerInvariant();

            bool isQuestion = Regex.IsMatch(lowerLast, @"^(who|what|where|when|why|how|which|whose|whom|is|are|am|was|were|do|does|did|can|could|would|should|will|won't|haven't|isn't|aren't|has|have|had)\b") ||
                              Regex.IsMatch(lowerLast, @"^(מי|מה|איפה|היכן|מתי|למה|מדוע|איך|כיצד|האם|כמה|לאן|מאין)\b");

            return trimmed + (isQuestion ? "?" : ".");
        }

        private string ApplySelfCorrections(string text)
        {
            string result = text;

            string tokenPattern = @"\b([A-Za-z0-9]+)[,;]?\s*(?:wait no|no wait|wait, no|no, wait|actually)[,;]?\s*([A-Za-z0-9]+)\b";
            result = Regex.Replace(result, tokenPattern, "$2", RegexOptions.IgnoreCase);

            string wordScratchPattern = @"\b([\w]+)[,;]?\s*\bscratch that\b[,;]?\s*";
            result = Regex.Replace(result, wordScratchPattern, string.Empty, RegexOptions.IgnoreCase);

            string sentenceScratchPattern = @"(?:^|[.\?!]\s*)(?:[^.\?!]+?)[.\?!]?\s*\bscratch that\b[.\?!]?\s*";
            result = Regex.Replace(result, sentenceScratchPattern, string.Empty, RegexOptions.IgnoreCase);

            string hebrewTokenPattern = @"([\u0590-\u05FF0-9]+)[,;]?\s*(?:בעצם לא|לא בעצם)[,;]?\s*([\u0590-\u05FF0-9]+)";
            result = Regex.Replace(result, hebrewTokenPattern, "$2");

            string hebrewSentencePattern = @"(?:^|[.\?!]\s*)(?:[^.\?!]+?)[.\?!]?\s*(?:תמחק את זה|מחק את זה)[.\?!]?\s*";
            result = Regex.Replace(result, hebrewSentencePattern, string.Empty);

            return result;
        }

        private string CapitalizeSentenceBoundaries(string text)
        {
            string pattern = @"(^|[.\?!\n]+[\s•]*|[•][ \t]*)([a-z])";
            return Regex.Replace(text, pattern, m => m.Groups[1].Value + m.Groups[2].Value.ToUpperInvariant());
        }
    }
}
