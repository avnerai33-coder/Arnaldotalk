using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Interop;

namespace ArnaldoTalk.Core
{
    public class GlobalHotkeyManager : IDisposable
    {
        private const int WM_HOTKEY = 0x0312;
        private const int HOTKEY_ID = 9001;
        private const int ESCAPE_HOTKEY_ID = 9002;
        private const uint VK_ESCAPE = 0x1B;

        private const int VK_SHIFT = 0x10;
        private const int VK_CONTROL = 0x11;
        private const int VK_MENU = 0x12; // Alt
        private const int VK_LWIN = 0x5B;

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int vKey);

        private IntPtr _hWnd;
        private HwndSource? _source;
        private uint _activeModifiers;
        private uint _activeVk;
        private CancellationTokenSource? _pttCts;

        public event Action? HotkeyDown;
        public event Action? HotkeyUp;
        public event Action? HotkeyPressed;
        public event Action? EscapePressed;

        public void Register(IntPtr hWnd)
        {
            _hWnd = hWnd;
            _source = HwndSource.FromHwnd(hWnd);
            _source?.AddHook(HwndHook);

            RegisterActiveFromSettings();
            RegisterEscapeKey();
        }

        public void RegisterActiveFromSettings()
        {
            if (_hWnd == IntPtr.Zero) return;

            UnregisterHotKey(_hWnd, HOTKEY_ID);

            var (modifiers, vk) = AppSettings.Shared.GetActiveHotkey();
            _activeModifiers = modifiers;
            _activeVk = vk;

            uint regModifiers = modifiers;
            uint regVk = vk;

            if (vk == KeyHelper.MODIFIER_ONLY_VK)
            {
                // Decompose modifier pair into fsModifier + virtual key
                if ((modifiers & KeyHelper.MOD_ALT) != 0 && (modifiers & KeyHelper.MOD_CONTROL) != 0)
                {
                    regModifiers = KeyHelper.MOD_ALT;
                    regVk = (uint)VK_CONTROL;
                }
                else if ((modifiers & KeyHelper.MOD_WIN) != 0 && (modifiers & KeyHelper.MOD_CONTROL) != 0)
                {
                    regModifiers = KeyHelper.MOD_WIN;
                    regVk = (uint)VK_CONTROL;
                }
                else if ((modifiers & KeyHelper.MOD_CONTROL) != 0 && (modifiers & KeyHelper.MOD_SHIFT) != 0)
                {
                    regModifiers = KeyHelper.MOD_CONTROL;
                    regVk = (uint)VK_SHIFT;
                }
                else if ((modifiers & KeyHelper.MOD_ALT) != 0 && (modifiers & KeyHelper.MOD_SHIFT) != 0)
                {
                    regModifiers = KeyHelper.MOD_ALT;
                    regVk = (uint)VK_SHIFT;
                }
                else if ((modifiers & KeyHelper.MOD_WIN) != 0 && (modifiers & KeyHelper.MOD_ALT) != 0)
                {
                    regModifiers = KeyHelper.MOD_WIN;
                    regVk = (uint)VK_MENU;
                }
                else
                {
                    regModifiers = KeyHelper.MOD_ALT;
                    regVk = (uint)VK_CONTROL;
                }
            }

            // 0x4000 = MOD_NOREPEAT
            uint flags = regModifiers | 0x4000;
            RegisterHotKey(_hWnd, HOTKEY_ID, flags, regVk);
        }

        private void RegisterEscapeKey()
        {
            if (_hWnd == IntPtr.Zero) return;
            RegisterHotKey(_hWnd, ESCAPE_HOTKEY_ID, 0, VK_ESCAPE);
        }

        private IntPtr HwndHook(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == WM_HOTKEY)
            {
                int id = wParam.ToInt32();
                if (id == ESCAPE_HOTKEY_ID)
                {
                    EscapePressed?.Invoke();
                    handled = true;
                    return IntPtr.Zero;
                }

                if (id == HOTKEY_ID)
                {
                    handled = true;
                    if (AppSettings.Shared.Mode == DictationMode.PushToTalk)
                    {
                        HandlePushToTalkKeyDown();
                    }
                    else
                    {
                        // In Toggle Mode, pressing the shortcut starts or stops dictating!
                        HotkeyPressed?.Invoke();
                    }
                }
            }
            return IntPtr.Zero;
        }

        private void HandlePushToTalkKeyDown()
        {
            _pttCts?.Cancel();
            _pttCts = new CancellationTokenSource();
            var token = _pttCts.Token;

            HotkeyDown?.Invoke();

            // Poll for key release
            Task.Run(async () =>
            {
                int vk = (int)_activeVk;
                if (_activeVk == KeyHelper.MODIFIER_ONLY_VK)
                {
                    vk = VK_CONTROL;
                }

                await Task.Delay(50, token);

                while (!token.IsCancellationRequested)
                {
                    short state = GetAsyncKeyState(vk);
                    bool isKeyDown = (state & 0x8000) != 0;

                    if (!isKeyDown)
                    {
                        HotkeyUp?.Invoke();
                        break;
                    }

                    await Task.Delay(25, token);
                }
            }, token);
        }

        public void Dispose()
        {
            _pttCts?.Cancel();
            if (_hWnd != IntPtr.Zero)
            {
                UnregisterHotKey(_hWnd, HOTKEY_ID);
                UnregisterHotKey(_hWnd, ESCAPE_HOTKEY_ID);
                _source?.RemoveHook(HwndHook);
            }
        }
    }
}
