using System;
using System.IO;
using System.Text.Json;

namespace ArnaldoTalk.Core
{
    public enum DictationMode
    {
        Toggle,
        PushToTalk
    }

    public enum HotkeyPreset
    {
        AltSpace,
        CtrlWinSpace,
        CtrlShiftSpace,
        CtrlSpace,
        F5,
        Custom
    }

    public class AppSettings
    {
        private static readonly Lazy<AppSettings> _instance = new(() => Load());
        public static AppSettings Shared => _instance.Value;

        public string SelectedLanguage { get; set; } = "en";
        public DictationMode Mode { get; set; } = DictationMode.Toggle;
        public HotkeyPreset Preset { get; set; } = HotkeyPreset.CtrlWinSpace;

        public uint CustomModifiers { get; set; } = 0x0002 | 0x0008; // MOD_CONTROL | MOD_WIN
        public uint CustomKey { get; set; } = 0x20;                  // VK_SPACE
        public string CustomDisplay { get; set; } = "Ctrl + Win + Space";

        public bool AutoPunctuationEnabled { get; set; } = true;
        public bool GrammarCorrectionEnabled { get; set; } = true;
        public bool SpokenPunctuationEnabled { get; set; } = true;
        public bool SmartSelfCorrectionEnabled { get; set; } = true;

        public event Action? SettingsChanged;

        public string ActiveShortcutDisplay
        {
            get
            {
                return Preset switch
                {
                    HotkeyPreset.AltSpace => "Alt + Space",
                    HotkeyPreset.CtrlWinSpace => "Ctrl + Win + Space",
                    HotkeyPreset.CtrlShiftSpace => "Ctrl + Shift + Space",
                    HotkeyPreset.CtrlSpace => "Ctrl + Space",
                    HotkeyPreset.F5 => "F5",
                    HotkeyPreset.Custom => CustomDisplay,
                    _ => "Ctrl + Win + Space"
                };
            }
        }

        public (uint modifiers, uint vk) GetActiveHotkey()
        {
            return Preset switch
            {
                HotkeyPreset.AltSpace => (0x0001 /* MOD_ALT */, 0x20 /* VK_SPACE */),
                HotkeyPreset.CtrlWinSpace => (0x0002 | 0x0008 /* MOD_CONTROL | MOD_WIN */, 0x20),
                HotkeyPreset.CtrlShiftSpace => (0x0002 | 0x0004 /* MOD_CONTROL | MOD_SHIFT */, 0x20),
                HotkeyPreset.CtrlSpace => (0x0002 /* MOD_CONTROL */, 0x20),
                HotkeyPreset.F5 => (0x0000, 0x74 /* VK_F5 */),
                HotkeyPreset.Custom => (CustomModifiers, CustomKey),
                _ => (0x0002 | 0x0008, 0x20)
            };
        }

        public void SetCustomShortcut(uint modifiers, uint vk, string display)
        {
            CustomModifiers = modifiers;
            CustomKey = vk;
            CustomDisplay = display;
            Preset = HotkeyPreset.Custom;
            Save();
            SettingsChanged?.Invoke();
        }

        public void SetPreset(HotkeyPreset preset)
        {
            Preset = preset;
            Save();
            SettingsChanged?.Invoke();
        }

        public void SetMode(DictationMode mode)
        {
            Mode = mode;
            Save();
            SettingsChanged?.Invoke();
        }

        public void SetLanguage(string lang)
        {
            SelectedLanguage = lang;
            Save();
            SettingsChanged?.Invoke();
        }

        public void Save()
        {
            try
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                string dir = Path.Combine(appData, "ArnaldoTalk");
                Directory.CreateDirectory(dir);
                string filePath = Path.Combine(dir, "settings.json");

                var options = new JsonSerializerOptions { WriteIndented = true };
                string json = JsonSerializer.Serialize(this, options);
                File.WriteAllText(filePath, json);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Failed to save settings: {ex.Message}");
            }
        }

        private static AppSettings Load()
        {
            try
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                string filePath = Path.Combine(appData, "ArnaldoTalk", "settings.json");
                if (File.Exists(filePath))
                {
                    string json = File.ReadAllText(filePath);
                    var settings = JsonSerializer.Deserialize<AppSettings>(json);
                    if (settings != null) return settings;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Failed to load settings: {ex.Message}");
            }

            return new AppSettings();
        }
    }
}

