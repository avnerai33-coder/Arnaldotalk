using System;
using System.Collections.Generic;
using System.IO;
using NAudio.Wave;
using NAudio.CoreAudioApi;

namespace ArnaldoTalk.Core
{
    public class AudioCaptureManager : IDisposable
    {
        public bool IsRecording { get; private set; }
        public float AudioLevel { get; private set; }
        public const int TargetSampleRate = 16000;

        public event Action<float>? AudioLevelChanged;
        public event Action<float[]>? BufferCaptured;

        private WasapiCapture? _capture;
        private readonly List<float> _accumulatedSamples = new();
        private readonly object _lock = new();

        public void StartRecording()
        {
            if (IsRecording) return;

            lock (_lock)
            {
                _accumulatedSamples.Clear();
            }

            _capture = new WasapiCapture();
            var currentCapture = _capture;
            var inputFormat = currentCapture.WaveFormat;

            currentCapture.DataAvailable += (s, e) =>
            {
                ProcessAudioBuffer(e.Buffer, e.BytesRecorded, inputFormat);
            };

            currentCapture.RecordingStopped += (s, e) =>
            {
                currentCapture.Dispose();
                if (ReferenceEquals(_capture, currentCapture))
                {
                    _capture = null;
                }
            };

            IsRecording = true;
            _capture.StartRecording();
        }

        public float[] StopRecording()
        {
            if (!IsRecording) return Array.Empty<float>();

            IsRecording = false;
            try
            {
                _capture?.StopRecording();
            }
            catch { }

            lock (_lock)
            {
                var recorded = _accumulatedSamples.ToArray();
                _accumulatedSamples.Clear();
                AudioLevel = 0.0f;
                AudioLevelChanged?.Invoke(0.0f);
                return recorded;
            }
        }

        private void ProcessAudioBuffer(byte[] buffer, int bytesRecorded, WaveFormat format)
        {
            if (bytesRecorded == 0) return;

            int channels = format.Channels;
            int bytesPerSample = format.BitsPerSample / 8;
            int sampleCount = bytesRecorded / (bytesPerSample * channels);

            float[] monoSamples = new float[sampleCount];
            double sumSquares = 0.0;

            for (int i = 0; i < sampleCount; i++)
            {
                float sample = 0;
                int offset = i * bytesPerSample * channels;

                if (format.Encoding == WaveFormatEncoding.IeeeFloat ||
                    format.BitsPerSample == 32 ||
                    (int)format.Encoding == 65534 /* Extensible */ && format.BitsPerSample == 32)
                {
                    sample = BitConverter.ToSingle(buffer, offset);
                }
                else if (format.BitsPerSample == 16)
                {
                    short val = BitConverter.ToInt16(buffer, offset);
                    sample = val / 32768.0f;
                }
                else if (format.BitsPerSample == 24)
                {
                    int val = (buffer[offset + 2] << 16) | (buffer[offset + 1] << 8) | buffer[offset];
                    if ((val & 0x800000) != 0) val |= unchecked((int)0xFF000000);
                    sample = val / 8388608.0f;
                }

                monoSamples[i] = sample;
                sumSquares += sample * sample;
            }

            float rms = (float)Math.Sqrt(sumSquares / Math.Max(sampleCount, 1));
            AudioLevel = Math.Clamp(rms * 5.0f, 0.0f, 1.0f);
            AudioLevelChanged?.Invoke(AudioLevel);

            // Resample to 16kHz
            float[] resampled = Resample(monoSamples, format.SampleRate, TargetSampleRate);

            lock (_lock)
            {
                _accumulatedSamples.AddRange(resampled);
            }

            BufferCaptured?.Invoke(resampled);
        }

        private static float[] Resample(float[] input, int sourceRate, int targetRate)
        {
            if (sourceRate == targetRate) return input;

            double ratio = (double)targetRate / sourceRate;
            int outputCount = (int)(input.Length * ratio);
            float[] output = new float[outputCount];

            for (int i = 0; i < outputCount; i++)
            {
                double srcIndex = i / ratio;
                int idx0 = (int)Math.Floor(srcIndex);
                int idx1 = Math.Min(idx0 + 1, input.Length - 1);
                double frac = srcIndex - idx0;

                output[i] = (float)((1.0 - frac) * input[idx0] + frac * input[idx1]);
            }

            return output;
        }

        public void Dispose()
        {
            if (IsRecording)
            {
                StopRecording();
            }
            _capture?.Dispose();
        }
    }
}

