using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace ArnaldoTalk.Core
{
    public class VocabularyManager
    {
        private static readonly Lazy<VocabularyManager> _instance = new(() => new VocabularyManager());
        public static VocabularyManager Shared => _instance.Value;

        private readonly object _lock = new();
        private Dictionary<string, string> _vocabulary = new(StringComparer.OrdinalIgnoreCase);
        private readonly string _filePath;

        private VocabularyManager()
        {
            string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string appDir = Path.Combine(appData, "ArnaldoTalk");
            Directory.CreateDirectory(appDir);
            _filePath = Path.Combine(appDir, "vocabulary.json");

            LoadVocabulary();
        }

        public IReadOnlyDictionary<string, string> GetVocabulary()
        {
            lock (_lock)
            {
                return new Dictionary<string, string>(_vocabulary, StringComparer.OrdinalIgnoreCase);
            }
        }

        public void SetWord(string spoken, string replacement)
        {
            lock (_lock)
            {
                _vocabulary[spoken.Trim().ToLowerInvariant()] = replacement.Trim();
                SaveToFile();
            }
        }

        public void RemoveWord(string spoken)
        {
            lock (_lock)
            {
                if (_vocabulary.Remove(spoken.Trim().ToLowerInvariant()))
                {
                    SaveToFile();
                }
            }
        }

        private void LoadVocabulary()
        {
            lock (_lock)
            {
                if (File.Exists(_filePath))
                {
                    try
                    {
                        string json = File.ReadAllText(_filePath);
                        var loaded = JsonSerializer.Deserialize<Dictionary<string, string>>(json);
                        if (loaded != null)
                        {
                            _vocabulary = new Dictionary<string, string>(loaded, StringComparer.OrdinalIgnoreCase);
                            return;
                        }
                    }
                    catch { /* Fallback to default */ }
                }

                // Check app directory fallback
                string bundledPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "vocabulary.json");
                if (File.Exists(bundledPath))
                {
                    try
                    {
                        string json = File.ReadAllText(bundledPath);
                        var bundled = JsonSerializer.Deserialize<Dictionary<string, string>>(json);
                        if (bundled != null)
                        {
                            _vocabulary = new Dictionary<string, string>(bundled, StringComparer.OrdinalIgnoreCase);
                            SaveToFile();
                            return;
                        }
                    }
                    catch { }
                }

                // Default dictionary
                _vocabulary = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                {
                    ["arnaldo"] = "Arnaldo",
                    ["arnaldo talk"] = "Arnaldo Talk",
                    ["github"] = "GitHub",
                    ["api"] = "API",
                    ["apis"] = "APIs",
                    ["graphql"] = "GraphQL",
                    ["kubernetes"] = "Kubernetes",
                    ["vs code"] = "VS Code",
                    ["windows"] = "Windows",
                    ["dotnet"] = ".NET"
                };
                SaveToFile();
            }
        }

        private void SaveToFile()
        {
            try
            {
                string json = JsonSerializer.Serialize(_vocabulary, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(_filePath, json);
            }
            catch { }
        }
    }
}

