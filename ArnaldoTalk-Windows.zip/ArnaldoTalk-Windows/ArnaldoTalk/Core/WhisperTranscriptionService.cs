using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Whisper.net;
using Whisper.net.Ggml;

namespace ArnaldoTalk.Core
{
    public class WhisperTranscriptionService : IDisposable
    {
        private WhisperFactory? _factory;
        private WhisperProcessor? _processor;
        private readonly string _modelPath;
        private bool _isInitialized;

        private string _language = "en"; // "en", "he", "auto"

        public string CurrentLanguage => _language;

        public void SetLanguage(string lang)
        {
            _language = string.IsNullOrWhiteSpace(lang) ? "en" : lang;
            if (_factory != null)
            {
                _processor?.Dispose();
                _processor = _factory.CreateBuilder()
                    .WithLanguage(_language)
                    .WithSegmentEventHandler(segment => { })
                    .Build();
            }
        }

        public WhisperTranscriptionService()
        {
            string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string modelDir = Path.Combine(appData, "ArnaldoTalk", "models");
            Directory.CreateDirectory(modelDir);
            _modelPath = Path.Combine(modelDir, "ggml-base.bin");
        }

        public async Task InitializeAsync()
        {
            if (_isInitialized) return;

            // Automatically download quantized Whisper model if missing
            if (!File.Exists(_modelPath))
            {
                using (var modelStream = await WhisperGgmlDownloader.GetGgmlModelAsync(GgmlType.Base))
                using (var fileWriter = File.OpenWrite(_modelPath))
                {
                    await modelStream.CopyToAsync(fileWriter);
                }
            }

            _factory = WhisperFactory.FromPath(_modelPath);
            _processor = _factory.CreateBuilder()
                .WithLanguage(_language)
                .WithSegmentEventHandler(segment => { })
                .Build();

            _isInitialized = true;
        }

        public async Task<string> TranscribeAsync(float[] samples, int sampleRate = 16000)
        {
            if (samples.Length < sampleRate * 0.15) // < 0.15s
            {
                return string.Empty;
            }

            if (!_isInitialized)
            {
                await InitializeAsync();
            }

            if (_processor == null) return string.Empty;

            var sb = new StringBuilder();

            // Convert float[] to WAV stream in memory for Whisper.net
            using var memoryStream = new MemoryStream();
            using (var writer = new BinaryWriter(memoryStream, Encoding.UTF8, leaveOpen: true))
            {
                WriteWavHeader(writer, samples.Length, sampleRate);
                foreach (var sample in samples)
                {
                    short val = (short)Math.Clamp(sample * 32767.0f, -32768f, 32767f);
                    writer.Write(val);
                }
            }
            memoryStream.Position = 0;

            await foreach (var segment in _processor.ProcessAsync(memoryStream))
            {
                sb.Append(segment.Text).Append(' ');
            }

            return sb.ToString().Trim();
        }

        private static void WriteWavHeader(BinaryWriter writer, int sampleCount, int sampleRate)
        {
            int subChunk2Size = sampleCount * 2;
            int chunkSize = 36 + subChunk2Size;

            writer.Write(Encoding.ASCII.GetBytes("RIFF"));
            writer.Write(chunkSize);
            writer.Write(Encoding.ASCII.GetBytes("WAVE"));
            writer.Write(Encoding.ASCII.GetBytes("fmt "));
            writer.Write(16); // SubChunk1Size (PCM)
            writer.Write((short)1); // AudioFormat (PCM)
            writer.Write((short)1); // NumChannels (Mono)
            writer.Write(sampleRate); // SampleRate
            writer.Write(sampleRate * 2); // ByteRate
            writer.Write((short)2); // BlockAlign
            writer.Write((short)16); // BitsPerSample
            writer.Write(Encoding.ASCII.GetBytes("data"));
            writer.Write(subChunk2Size);
        }

        public void Dispose()
        {
            _processor?.Dispose();
            _factory?.Dispose();
        }
    }
}

