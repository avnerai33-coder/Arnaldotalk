using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace ArnaldoTalk.Core
{
    public class TypingService
    {
        private static readonly Lazy<TypingService> _instance = new(() => new TypingService());
        public static TypingService Shared => _instance.Value;

        [StructLayout(LayoutKind.Sequential)]
        private struct INPUT
        {
            public uint type;
            public InputUnion u;
        }

        [StructLayout(LayoutKind.Explicit)]
        private struct InputUnion
        {
            [FieldOffset(0)] public MOUSEINPUT mi;
            [FieldOffset(0)] public KEYBDINPUT ki;
            [FieldOffset(0)] public HARDWAREINPUT hi;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct KEYBDINPUT
        {
            public ushort wVk;
            public ushort wScan;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MOUSEINPUT
        {
            public int dx;
            public int dy;
            public uint mouseData;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct HARDWAREINPUT
        {
            public uint uMsg;
            public ushort wParamL;
            public ushort wParamH;
        }

        private const uint INPUT_KEYBOARD = 1;
        private const uint KEYEVENTF_KEYUP = 0x0002;
        private const uint KEYEVENTF_UNICODE = 0x0004;

        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        private TypingService() { }

        public async Task TypeTextAsync(string text)
        {
            if (string.IsNullOrEmpty(text)) return;

            await Task.Run(() =>
            {
                var inputs = new List<INPUT>();

                foreach (char c in text)
                {
                    if (c == '\r') continue;

                    if (c == '\n')
                    {
                        // Send Enter key for newline in Windows edit controls
                        inputs.Add(new INPUT
                        {
                            type = INPUT_KEYBOARD,
                            u = new InputUnion
                            {
                                ki = new KEYBDINPUT
                                {
                                    wVk = 0x0D, // VK_RETURN
                                    wScan = 0,
                                    dwFlags = 0
                                }
                            }
                        });
                        inputs.Add(new INPUT
                        {
                            type = INPUT_KEYBOARD,
                            u = new InputUnion
                            {
                                ki = new KEYBDINPUT
                                {
                                    wVk = 0x0D, // VK_RETURN
                                    wScan = 0,
                                    dwFlags = KEYEVENTF_KEYUP
                                }
                            }
                        });
                        continue;
                    }

                    // Key down
                    inputs.Add(new INPUT
                    {
                        type = INPUT_KEYBOARD,
                        u = new InputUnion
                        {
                            ki = new KEYBDINPUT
                            {
                                wVk = 0,
                                wScan = (ushort)c,
                                dwFlags = KEYEVENTF_UNICODE
                            }
                        }
                    });

                    // Key up
                    inputs.Add(new INPUT
                    {
                        type = INPUT_KEYBOARD,
                        u = new InputUnion
                        {
                            ki = new KEYBDINPUT
                            {
                                wVk = 0,
                                wScan = (ushort)c,
                                dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP
                            }
                        }
                    });
                }

                if (inputs.Count > 0)
                {
                    SendInput((uint)inputs.Count, inputs.ToArray(), Marshal.SizeOf(typeof(INPUT)));
                }
            });
        }
    }
}

