using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace ArnaldoTalk.Core
{
    public class DictationCoordinator
    {
        public AudioCaptureManager AudioCapture { get; } = new();
        public WhisperTranscriptionService TranscriptionService { get; } = new();
        public TypingService TypingService => TypingService.Shared;
        public TextEnhancer TextEnhancer => TextEnhancer.Shared;

        public event Action<string>? StatusChanged;
        public event Action<string>? LiveTextChanged;

        public bool IsRecording => AudioCapture.IsRecording;

        public DictationCoordinator()
        {
            SetLanguage(AppSettings.Shared.SelectedLanguage);

            AppSettings.Shared.SettingsChanged += () =>
            {
                SetLanguage(AppSettings.Shared.SelectedLanguage);
            };

            AudioCapture.BufferCaptured += samples =>
            {
                // Can be wired to live streaming if needed
            };
        }

        public void SetLanguage(string lang)
        {
            TranscriptionService.SetLanguage(lang);
        }

        public async Task ToggleDictationAsync()
        {
            if (IsRecording)
            {
                await StopAndInjectAsync();
            }
            else
            {
                StartDictation();
            }
        }

        public void StartDictation()
        {
            if (IsRecording) return;
            StatusChanged?.Invoke("Listening...");
            AudioCapture.StartRecording();
        }

        public void CancelDictation()
        {
            if (!IsRecording) return;
            AudioCapture.StopRecording();
            StatusChanged?.Invoke("Cancelled");
        }

        public async Task StopAndInjectAsync()
        {
            if (!IsRecording) return;

            StatusChanged?.Invoke("Transcribing...");
            var samples = AudioCapture.StopRecording();

            if (samples.Length == 0)
            {
                StatusChanged?.Invoke("No audio");
                return;
            }

            try
            {
                string rawText = await TranscriptionService.TranscribeAsync(samples);
                var settings = AppSettings.Shared;

                string cleanedText = TextEnhancer.CleanTranscript(
                    rawText,
                    spokenPunctuation: settings.SpokenPunctuationEnabled,
                    selfCorrection: settings.SmartSelfCorrectionEnabled,
                    autoPunctuation: settings.AutoPunctuationEnabled,
                    grammarCorrection: settings.GrammarCorrectionEnabled
                );

                if (string.IsNullOrWhiteSpace(cleanedText))
                {
                    StatusChanged?.Invoke("No speech detected");
                    return;
                }

                StatusChanged?.Invoke("Transcribed!");
                await TypingService.TypeTextAsync(cleanedText);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Transcription error: {ex.Message}");
                StatusChanged?.Invoke("Error transcribing");
            }
        }
    }
}
