using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ArnaldoTalk.Core;

namespace ArnaldoTalk
{
    public partial class SettingsWindow : Window
    {
        private bool _isRecording = false;
        private readonly List<string> _tickedIds = new();

        public SettingsWindow()
        {
            InitializeComponent();
            PopulateKeysCombo();
            LoadCurrentSettings();
            PreviewKeyDown += SettingsWindow_PreviewKeyDown;
        }

        private void PopulateKeysCombo()
        {
            ComboKeys.ItemsSource = KeyHelper.AllSelectableKeys;
            ComboKeys.DisplayMemberPath = "Name";
            ComboKeys.SelectedValuePath = "Vk";
            ComboKeys.SelectedValue = (uint)0x4B; // K
        }

        private void LoadCurrentSettings()
        {
            var settings = AppSettings.Shared;

            // Mode
            if (settings.Mode == DictationMode.Toggle)
                RadioToggle.IsChecked = true;
            else
                RadioPushToTalk.IsChecked = true;

            // Language
            if (settings.SelectedLanguage == "he")
                RadioLangHebrew.IsChecked = true;
            else if (settings.SelectedLanguage == "auto")
                RadioLangAuto.IsChecked = true;
            else
                RadioLangEnglish.IsChecked = true;

            // Active Shortcut
            LabelActiveShortcut.Text = settings.ActiveShortcutDisplay;
            SyncTickedCheckboxes();

            // Features
            ChkAutoPunctuation.IsChecked = settings.AutoPunctuationEnabled;
            ChkGrammar.IsChecked = settings.GrammarCorrectionEnabled;
            ChkSpokenPunctuation.IsChecked = settings.SpokenPunctuationEnabled;
            ChkSelfCorrection.IsChecked = settings.SmartSelfCorrectionEnabled;
        }

        private void SyncTickedCheckboxes()
        {
            _tickedIds.Clear();
            var (mods, vk) = AppSettings.Shared.GetActiveHotkey();

            if ((mods & KeyHelper.MOD_ALT) != 0) _tickedIds.Add("alt");
            if ((mods & KeyHelper.MOD_CONTROL) != 0) _tickedIds.Add("ctrl");
            if ((mods & KeyHelper.MOD_WIN) != 0) _tickedIds.Add("win");
            if ((mods & KeyHelper.MOD_SHIFT) != 0) _tickedIds.Add("shift");

            if (vk != KeyHelper.MODIFIER_ONLY_VK)
            {
                if (vk == 0x20) _tickedIds.Add("space");
                else if (vk == 0x0D) _tickedIds.Add("enter");
                else if (vk == 0x09) _tickedIds.Add("tab");
                else if (vk == 0x1B) _tickedIds.Add("esc");
                else if (vk == 0x4B) _tickedIds.Add("k");
                else if (vk == 0x44) _tickedIds.Add("d");
                else if (vk == 0x74) _tickedIds.Add("f5");
            }

            TickAlt.IsChecked = _tickedIds.Contains("alt");
            TickCtrl.IsChecked = _tickedIds.Contains("ctrl");
            TickWin.IsChecked = _tickedIds.Contains("win");
            TickShift.IsChecked = _tickedIds.Contains("shift");
            TickSpace.IsChecked = _tickedIds.Contains("space");
            TickEnter.IsChecked = _tickedIds.Contains("enter");
            TickTab.IsChecked = _tickedIds.Contains("tab");
            TickEsc.IsChecked = _tickedIds.Contains("esc");
            TickK.IsChecked = _tickedIds.Contains("k");
            TickD.IsChecked = _tickedIds.Contains("d");
            TickF5.IsChecked = _tickedIds.Contains("f5");

            UpdateStatusText();
        }

        private void OnTickButtonClicked(object sender, RoutedEventArgs e)
        {
            if (sender is not CheckBox cb) return;

            string id = cb.Name.Replace("Tick", "").ToLowerInvariant();

            if (cb.IsChecked == true)
            {
                if (!_tickedIds.Contains(id))
                {
                    if (_tickedIds.Count >= 2)
                    {
                        string oldest = _tickedIds[0];
                        _tickedIds.RemoveAt(0);
                        SetCheckBoxChecked(oldest, false);
                    }
                    _tickedIds.Add(id);
                }
            }
            else
            {
                _tickedIds.Remove(id);
            }

            UpdateStatusText();

            if (_tickedIds.Count == 2)
            {
                ApplyTickedTwoButtons();
            }
        }

        private void SetCheckBoxChecked(string id, bool isChecked)
        {
            switch (id)
            {
                case "alt": TickAlt.IsChecked = isChecked; break;
                case "ctrl": TickCtrl.IsChecked = isChecked; break;
                case "win": TickWin.IsChecked = isChecked; break;
                case "shift": TickShift.IsChecked = isChecked; break;
                case "space": TickSpace.IsChecked = isChecked; break;
                case "enter": TickEnter.IsChecked = isChecked; break;
                case "tab": TickTab.IsChecked = isChecked; break;
                case "esc": TickEsc.IsChecked = isChecked; break;
                case "k": TickK.IsChecked = isChecked; break;
                case "d": TickD.IsChecked = isChecked; break;
                case "f5": TickF5.IsChecked = isChecked; break;
            }
        }

        private void UpdateStatusText()
        {
            if (_tickedIds.Count == 0)
                LabelSelectionStatus.Text = "Tick 2 buttons to activate";
            else if (_tickedIds.Count == 1)
                LabelSelectionStatus.Text = "1 of 2 ticked — tick 1 more";
            else
                LabelSelectionStatus.Text = "✓ 2 buttons active";
        }

        private void ApplyTickedTwoButtons()
        {
            uint mods = 0;
            uint vk = KeyHelper.MODIFIER_ONLY_VK;

            foreach (var id in _tickedIds)
            {
                var item = KeyHelper.TickableButtons.FirstOrDefault(b => b.Id == id);
                if (item != null)
                {
                    if (item.IsModifier)
                        mods |= item.Modifier;
                    else
                        vk = item.Vk;
                }
            }

            string display = KeyHelper.FormatShortcut(mods, vk);
            AppSettings.Shared.SetCustomShortcut(mods, vk, display);
            LabelActiveShortcut.Text = display;
        }

        private void BtnApplyOtherKey_Click(object sender, RoutedEventArgs e)
        {
            uint vk = (uint)(ComboKeys.SelectedValue ?? (uint)0x4B);

            // Keep one modifier if ticked, or default to Alt
            uint mods = 0;
            if (TickAlt.IsChecked == true) mods |= KeyHelper.MOD_ALT;
            if (TickCtrl.IsChecked == true) mods |= KeyHelper.MOD_CONTROL;
            if (TickWin.IsChecked == true) mods |= KeyHelper.MOD_WIN;
            if (TickShift.IsChecked == true) mods |= KeyHelper.MOD_SHIFT;

            if (mods == 0) mods = KeyHelper.MOD_ALT;

            string display = KeyHelper.FormatShortcut(mods, vk);
            AppSettings.Shared.SetCustomShortcut(mods, vk, display);
            LabelActiveShortcut.Text = display;
            SyncTickedCheckboxes();
        }

        private void Preset_AltSpace_Click(object sender, RoutedEventArgs e)
        {
            AppSettings.Shared.SetPreset(HotkeyPreset.AltSpace);
            LabelActiveShortcut.Text = AppSettings.Shared.ActiveShortcutDisplay;
            SyncTickedCheckboxes();
        }

        private void Preset_AltCtrl_Click(object sender, RoutedEventArgs e)
        {
            AppSettings.Shared.SetCustomShortcut(KeyHelper.MOD_ALT | KeyHelper.MOD_CONTROL, KeyHelper.MODIFIER_ONLY_VK, "Alt + Ctrl");
            LabelActiveShortcut.Text = AppSettings.Shared.ActiveShortcutDisplay;
            SyncTickedCheckboxes();
        }

        private void Preset_CtrlWin_Click(object sender, RoutedEventArgs e)
        {
            AppSettings.Shared.SetPreset(HotkeyPreset.CtrlWinSpace);
            LabelActiveShortcut.Text = AppSettings.Shared.ActiveShortcutDisplay;
            SyncTickedCheckboxes();
        }

        private void Preset_CtrlSpace_Click(object sender, RoutedEventArgs e)
        {
            AppSettings.Shared.SetPreset(HotkeyPreset.CtrlSpace);
            LabelActiveShortcut.Text = AppSettings.Shared.ActiveShortcutDisplay;
            SyncTickedCheckboxes();
        }

        private void Preset_CtrlShift_Click(object sender, RoutedEventArgs e)
        {
            AppSettings.Shared.SetCustomShortcut(KeyHelper.MOD_CONTROL | KeyHelper.MOD_SHIFT, KeyHelper.MODIFIER_ONLY_VK, "Ctrl + Shift");
            LabelActiveShortcut.Text = AppSettings.Shared.ActiveShortcutDisplay;
            SyncTickedCheckboxes();
        }

        private void Preset_F5_Click(object sender, RoutedEventArgs e)
        {
            AppSettings.Shared.SetPreset(HotkeyPreset.F5);
            LabelActiveShortcut.Text = AppSettings.Shared.ActiveShortcutDisplay;
            SyncTickedCheckboxes();
        }

        private void BtnRecord_Click(object sender, RoutedEventArgs e)
        {
            _isRecording = true;
            BtnRecord.Content = "🔴 Press any two buttons on keyboard now (or Esc)...";
            BtnRecord.Background = System.Windows.Media.Brushes.DarkRed;
        }

        private void SettingsWindow_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (!_isRecording) return;

            if (e.Key == Key.Escape)
            {
                StopRecording();
                e.Handled = true;
                return;
            }

            if (e.Key == Key.LeftCtrl || e.Key == Key.RightCtrl ||
                e.Key == Key.LeftAlt || e.Key == Key.RightAlt ||
                e.Key == Key.LeftShift || e.Key == Key.RightShift ||
                e.Key == Key.LWin || e.Key == Key.RWin ||
                e.Key == Key.System)
            {
                return;
            }

            uint modifiers = 0;
            if (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt) || e.SystemKey != Key.None)
                modifiers |= KeyHelper.MOD_ALT;
            if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
                modifiers |= KeyHelper.MOD_CONTROL;
            if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
                modifiers |= KeyHelper.MOD_SHIFT;
            if (Keyboard.IsKeyDown(Key.LWin) || Keyboard.IsKeyDown(Key.RWin))
                modifiers |= KeyHelper.MOD_WIN;

            Key key = e.Key == Key.System ? e.SystemKey : e.Key;
            uint vk = (uint)KeyInterop.VirtualKeyFromKey(key);

            string display = KeyHelper.FormatShortcut(modifiers, vk);
            AppSettings.Shared.SetCustomShortcut(modifiers, vk, display);

            LabelActiveShortcut.Text = display;
            StopRecording();
            SyncTickedCheckboxes();
            e.Handled = true;
        }

        private void StopRecording()
        {
            _isRecording = false;
            BtnRecord.Content = "⌨️ Or Click to Record Directly From Keyboard";
            BtnRecord.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(2, 132, 199));
        }

        private void ModeChanged(object sender, RoutedEventArgs e)
        {
            if (RadioToggle.IsChecked == true)
                AppSettings.Shared.SetMode(DictationMode.Toggle);
            else
                AppSettings.Shared.SetMode(DictationMode.PushToTalk);
        }

        private void LanguageChanged(object sender, RoutedEventArgs e)
        {
            if (RadioLangHebrew.IsChecked == true)
                AppSettings.Shared.SetLanguage("he");
            else if (RadioLangAuto.IsChecked == true)
                AppSettings.Shared.SetLanguage("auto");
            else
                AppSettings.Shared.SetLanguage("en");
        }

        private void FeatureChanged(object sender, RoutedEventArgs e)
        {
            var s = AppSettings.Shared;
            s.AutoPunctuationEnabled = ChkAutoPunctuation.IsChecked == true;
            s.GrammarCorrectionEnabled = ChkGrammar.IsChecked == true;
            s.SpokenPunctuationEnabled = ChkSpokenPunctuation.IsChecked == true;
            s.SmartSelfCorrectionEnabled = ChkSelfCorrection.IsChecked == true;
            s.Save();
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
