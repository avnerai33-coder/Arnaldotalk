using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using ArnaldoTalk.Core;

namespace ArnaldoTalk
{
    public partial class MainWindow : Window
    {
        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_NOACTIVATE = 0x08000000;
        private const int WS_EX_TOOLWINDOW = 0x00000080;

        [DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        private readonly DictationCoordinator _coordinator = new();
        private readonly GlobalHotkeyManager _hotkeyManager = new();

        public MainWindow()
        {
            InitializeComponent();
            SetupContextMenu();
            Loaded += MainWindow_Loaded;
            Closed += (s, e) => _hotkeyManager.Dispose();
        }

        private void SetupContextMenu()
        {
            var menu = new ContextMenu();
            var settings = AppSettings.Shared;

            // 1. Language Submenu
            var langMenu = new MenuItem { Header = $"Language ({settings.SelectedLanguage.ToUpper()})" };
            var langEnglish = new MenuItem { Header = "English (US) 🇺🇸", IsChecked = settings.SelectedLanguage == "en" };
            var langHebrew = new MenuItem { Header = "Hebrew (עברית) 🇮🇱", IsChecked = settings.SelectedLanguage == "he" };
            var langAuto = new MenuItem { Header = "Auto-Detect 🌐", IsChecked = settings.SelectedLanguage == "auto" };

            langEnglish.Click += (s, e) => { settings.SetLanguage("en"); SetupContextMenu(); };
            langHebrew.Click += (s, e) => { settings.SetLanguage("he"); SetupContextMenu(); };
            langAuto.Click += (s, e) => { settings.SetLanguage("auto"); SetupContextMenu(); };

            langMenu.Items.Add(langEnglish);
            langMenu.Items.Add(langHebrew);
            langMenu.Items.Add(langAuto);
            menu.Items.Add(langMenu);

            // 2. Dictate Button Submenu
            var shortcutMenu = new MenuItem { Header = $"Dictate Button ({settings.ActiveShortcutDisplay})" };

            var pAltSpace = new MenuItem { Header = "Alt + Space (Wispr Flow Style)", IsChecked = settings.Preset == HotkeyPreset.AltSpace };
            pAltSpace.Click += (s, e) => { settings.SetPreset(HotkeyPreset.AltSpace); SetupContextMenu(); };

            var pCtrlWin = new MenuItem { Header = "Ctrl + Win + Space", IsChecked = settings.Preset == HotkeyPreset.CtrlWinSpace };
            pCtrlWin.Click += (s, e) => { settings.SetPreset(HotkeyPreset.CtrlWinSpace); SetupContextMenu(); };

            var pCtrlShift = new MenuItem { Header = "Ctrl + Shift + Space", IsChecked = settings.Preset == HotkeyPreset.CtrlShiftSpace };
            pCtrlShift.Click += (s, e) => { settings.SetPreset(HotkeyPreset.CtrlShiftSpace); SetupContextMenu(); };

            var pCtrlSpace = new MenuItem { Header = "Ctrl + Space", IsChecked = settings.Preset == HotkeyPreset.CtrlSpace };
            pCtrlSpace.Click += (s, e) => { settings.SetPreset(HotkeyPreset.CtrlSpace); SetupContextMenu(); };

            var pF5 = new MenuItem { Header = "F5 Function Key", IsChecked = settings.Preset == HotkeyPreset.F5 };
            pF5.Click += (s, e) => { settings.SetPreset(HotkeyPreset.F5); SetupContextMenu(); };

            var pCustom = new MenuItem { Header = $"Custom: {settings.CustomDisplay}", IsChecked = settings.Preset == HotkeyPreset.Custom };
            pCustom.Click += (s, e) => { OpenSettings(); };

            shortcutMenu.Items.Add(pAltSpace);
            shortcutMenu.Items.Add(pCtrlWin);
            shortcutMenu.Items.Add(pCtrlShift);
            shortcutMenu.Items.Add(pCtrlSpace);
            shortcutMenu.Items.Add(pF5);
            shortcutMenu.Items.Add(pCustom);
            menu.Items.Add(shortcutMenu);

            // 3. Mode Submenu
            string modeDisplay = settings.Mode == DictationMode.PushToTalk ? "Push-to-Talk" : "Toggle";
            var modeMenu = new MenuItem { Header = $"Mode ({modeDisplay})" };

            var mPtt = new MenuItem { Header = "🎙️ Push-to-Talk (Hold button to speak)", IsChecked = settings.Mode == DictationMode.PushToTalk };
            mPtt.Click += (s, e) => { settings.SetMode(DictationMode.PushToTalk); SetupContextMenu(); };

            var mToggle = new MenuItem { Header = "🔁 Toggle Mode (Click to start/stop)", IsChecked = settings.Mode == DictationMode.Toggle };
            mToggle.Click += (s, e) => { settings.SetMode(DictationMode.Toggle); SetupContextMenu(); };

            modeMenu.Items.Add(mPtt);
            modeMenu.Items.Add(mToggle);
            menu.Items.Add(modeMenu);

            menu.Items.Add(new Separator());

            // 4. Settings Dialog
            var settingsItem = new MenuItem { Header = "Settings & Shortcuts..." };
            settingsItem.Click += (s, e) => OpenSettings();
            menu.Items.Add(settingsItem);

            menu.Items.Add(new Separator());

            // 5. Exit
            var exitItem = new MenuItem { Header = "Exit Arnaldo Talk" };
            exitItem.Click += (s, e) => Application.Current.Shutdown();
            menu.Items.Add(exitItem);

            ContextMenu = menu;
        }

        private void OpenSettings()
        {
            var win = new SettingsWindow();
            win.Owner = this;
            win.ShowDialog();
            SetupContextMenu();
            UpdateDefaultStatus();
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Position under top-center edge of primary screen
            Left = (SystemParameters.PrimaryScreenWidth - Width) / 2;
            Top = 20;

            UpdateDefaultStatus();

            // Register global hotkey
            var helper = new WindowInteropHelper(this);
            _hotkeyManager.Register(helper.Handle);

            // Wire Toggle Mode
            _hotkeyManager.HotkeyPressed += async () =>
            {
                await Dispatcher.InvokeAsync(async () =>
                {
                    await _coordinator.ToggleDictationAsync();
                });
            };

            // Wire Push-to-Talk Mode
            _hotkeyManager.HotkeyDown += () =>
            {
                Dispatcher.Invoke(() =>
                {
                    _coordinator.StartDictation();
                });
            };

            _hotkeyManager.HotkeyUp += async () =>
            {
                await Dispatcher.InvokeAsync(async () =>
                {
                    await _coordinator.StopAndInjectAsync();
                });
            };

            // Wire Escape Cancel
            _hotkeyManager.EscapePressed += () =>
            {
                Dispatcher.Invoke(() =>
                {
                    _coordinator.CancelDictation();
                });
            };

            // Wire Settings Changes
            AppSettings.Shared.SettingsChanged += () =>
            {
                Dispatcher.Invoke(() =>
                {
                    _hotkeyManager.RegisterActiveFromSettings();
                    UpdateDefaultStatus();
                    SetupContextMenu();
                });
            };

            // Wire status updates
            _coordinator.StatusChanged += status =>
            {
                Dispatcher.Invoke(() =>
                {
                    UpdateStatus(status);
                });
            };

            // Wire audio level animation
            _coordinator.AudioCapture.AudioLevelChanged += level =>
            {
                Dispatcher.Invoke(() =>
                {
                    UpdateWaveform(level);
                });
            };
        }

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);

            // Set window styles to non-activating tool window (prevents stealing focus)
            var helper = new WindowInteropHelper(this);
            int exStyle = GetWindowLong(helper.Handle, GWL_EXSTYLE);
            SetWindowLong(helper.Handle, GWL_EXSTYLE, exStyle | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW);
        }

        private void UpdateDefaultStatus()
        {
            if (!_coordinator.IsRecording)
            {
                StatusLabel.Text = $"Arnaldo Talk ({AppSettings.Shared.ActiveShortcutDisplay})";
                Width = 270;
                Left = (SystemParameters.PrimaryScreenWidth - Width) / 2;
            }
        }

        private void UpdateStatus(string status)
        {
            StatusLabel.Text = status;

            // Dynamically adjust width based on message
            double newWidth = Math.Clamp(120 + status.Length * 8.5, 240, 500);
            Width = newWidth;
            Left = (SystemParameters.PrimaryScreenWidth - Width) / 2;

            if (status == "Transcribed!" || status == "No speech detected" || status == "Cancelled")
            {
                Task.Delay(1200).ContinueWith(_ =>
                {
                    Dispatcher.Invoke(() =>
                    {
                        UpdateDefaultStatus();
                    });
                });
            }
        }

        private void UpdateWaveform(float level)
        {
            if (WaveformPanel.Children.Count >= 5)
            {
                for (int i = 0; i < 5; i++)
                {
                    if (WaveformPanel.Children[i] is System.Windows.Shapes.Rectangle rect)
                    {
                        double baseHeight = 6.0;
                        double variance = Math.Sin(i * 0.8) * 0.3 + 0.7;
                        rect.Height = Math.Clamp(baseHeight + level * 24.0 * variance, 4.0, 26.0);
                    }
                }
            }
        }
    }
}
