using System.Windows;

namespace ArnaldoTalk
{
    public partial class App : Application
    {
    }
}

