using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using ArnaldoTalk.Core;

namespace ArnaldoTalk.Tests
{
    public class AudioAndTranscriptionServiceTests
    {
        [Fact]
        public async Task TestSubThresholdAudioSilenceHandling()
        {
            var service = new WhisperTranscriptionService();

            // 1. Audio too short (< 0.15s = < 2400 samples at 16kHz)
            float[] shortSamples = new float[1000];
            Array.Fill(shortSamples, 0.1f);
            string resultShort = await service.TranscribeAsync(shortSamples, 16000);
            Assert.Equal(string.Empty, resultShort);

            // 2. Empty samples buffer
            string resultEmpty = await service.TranscribeAsync(Array.Empty<float>(), 16000);
            Assert.Equal(string.Empty, resultEmpty);
        }

        [Fact]
        public void TestWavHeaderWriterIntegrity()
        {
            // Verify standard 44-byte WAV header structure matches RIFF standard
            using var memoryStream = new MemoryStream();
            using (var writer = new BinaryWriter(memoryStream, Encoding.UTF8, leaveOpen: true))
            {
                int sampleCount = 16000; // 1 second
                int sampleRate = 16000;
                int subChunk2Size = sampleCount * 2; // 16-bit PCM = 2 bytes/sample
                int chunkSize = 36 + subChunk2Size;

                writer.Write(Encoding.ASCII.GetBytes("RIFF"));
                writer.Write(chunkSize);
                writer.Write(Encoding.ASCII.GetBytes("WAVE"));
                writer.Write(Encoding.ASCII.GetBytes("fmt "));
                writer.Write(16); // SubChunk1Size (PCM)
                writer.Write((short)1); // AudioFormat (PCM)
                writer.Write((short)1); // NumChannels (Mono)
                writer.Write(sampleRate);
                writer.Write(sampleRate * 2); // ByteRate
                writer.Write((short)2); // BlockAlign
                writer.Write((short)16); // BitsPerSample
                writer.Write(Encoding.ASCII.GetBytes("data"));
                writer.Write(subChunk2Size);
            }

            byte[] headerBytes = memoryStream.ToArray();
            Assert.Equal(44, headerBytes.Length);

            string riff = Encoding.ASCII.GetString(headerBytes, 0, 4);
            Assert.Equal("RIFF", riff);

            string wave = Encoding.ASCII.GetString(headerBytes, 8, 4);
            Assert.Equal("WAVE", wave);

            string fmt = Encoding.ASCII.GetString(headerBytes, 12, 4);
            Assert.Equal("fmt ", fmt);

            short formatCode = BitConverter.ToInt16(headerBytes, 20);
            Assert.Equal(1, formatCode); // PCM

            short channels = BitConverter.ToInt16(headerBytes, 22);
            Assert.Equal(1, channels); // Mono

            int rate = BitConverter.ToInt32(headerBytes, 24);
            Assert.Equal(16000, rate);

            string data = Encoding.ASCII.GetString(headerBytes, 36, 4);
            Assert.Equal("data", data);
        }

        [Fact]
        public void TestAudioResamplingMath()
        {
            // Verify linear interpolation resamples 48kHz mono signal down to 16kHz (3:1 ratio)
            int sourceRate = 48000;
            int targetRate = 16000;
            float[] input = new float[480]; // 10ms of audio
            for (int i = 0; i < input.Length; i++)
            {
                input[i] = (float)Math.Sin(2.0 * Math.PI * 440.0 * i / sourceRate);
            }

            double ratio = (double)targetRate / sourceRate;
            int outputCount = (int)(input.Length * ratio);
            float[] output = new float[outputCount];

            for (int i = 0; i < outputCount; i++)
            {
                double srcIndex = i / ratio;
                int idx0 = (int)Math.Floor(srcIndex);
                int idx1 = Math.Min(idx0 + 1, input.Length - 1);
                double frac = srcIndex - idx0;

                output[i] = (float)((1.0 - frac) * input[idx0] + frac * input[idx1]);
            }

            Assert.Equal(160, output.Length); // Exactly 160 samples (10ms at 16kHz)
            // Verify signal bounds preserved
            foreach (float s in output)
            {
                Assert.InRange(s, -1.01f, 1.01f);
            }
        }
    }
}
