using System;
using System.IO;
using Xunit;
using ArnaldoTalk.Core;

namespace ArnaldoTalk.Tests
{
    public class AppSettingsAndKeyHelperTests
    {
        [Fact]
        public void TestDefaultAppSettings()
        {
            var settings = AppSettings.Shared;

            // Default preset must be CtrlWinSpace to match README, UI, and run.bat
            Assert.Equal(HotkeyPreset.CtrlWinSpace, settings.Preset);
            Assert.Equal("Ctrl + Win + Space", settings.ActiveShortcutDisplay);

            var (mods, vk) = settings.GetActiveHotkey();
            Assert.Equal(0x0002u | 0x0008u, mods); // MOD_CONTROL | MOD_WIN
            Assert.Equal(0x20u, vk);               // VK_SPACE
        }

        [Fact]
        public void TestPresetSwitching()
        {
            var settings = AppSettings.Shared;

            settings.SetPreset(HotkeyPreset.AltSpace);
            Assert.Equal("Alt + Space", settings.ActiveShortcutDisplay);
            var (modsAlt, vkAlt) = settings.GetActiveHotkey();
            Assert.Equal(0x0001u, modsAlt);
            Assert.Equal(0x20u, vkAlt);

            settings.SetPreset(HotkeyPreset.F5);
            Assert.Equal("F5", settings.ActiveShortcutDisplay);
            var (modsF5, vkF5) = settings.GetActiveHotkey();
            Assert.Equal(0x0000u, modsF5);
            Assert.Equal(0x74u, vkF5);

            // Reset back to CtrlWinSpace
            settings.SetPreset(HotkeyPreset.CtrlWinSpace);
            Assert.Equal("Ctrl + Win + Space", settings.ActiveShortcutDisplay);
        }

        [Fact]
        public void TestKeyHelperFormattingAndBadges()
        {
            string formatted1 = KeyHelper.FormatShortcut(KeyHelper.MOD_CONTROL | KeyHelper.MOD_WIN, 0x20);
            Assert.Equal("Ctrl + Win + Space", formatted1);

            string formatted2 = KeyHelper.FormatShortcut(KeyHelper.MOD_ALT | KeyHelper.MOD_CONTROL, KeyHelper.MODIFIER_ONLY_VK);
            Assert.Equal("Ctrl + Alt", formatted2);

            var badges = KeyHelper.GetModifierBadges(KeyHelper.MOD_CONTROL | KeyHelper.MOD_SHIFT);
            Assert.Contains("Ctrl", badges);
            Assert.Contains("Shift", badges);
        }

        [Fact]
        public void TestHebrewCharacterDetection()
        {
            Assert.True(KeyHelper.ContainsHebrew("שלום עולם"));
            Assert.True(KeyHelper.ContainsHebrew("מה קורה?"));
            Assert.True(KeyHelper.ContainsHebrew("Testing שלום text"));
            Assert.False(KeyHelper.ContainsHebrew("Hello world"));
            Assert.False(KeyHelper.ContainsHebrew("12345 @#$%"));
            Assert.False(KeyHelper.ContainsHebrew(""));
        }

        [Fact]
        public void TestVocabularyManagerOperations()
        {
            var vocabManager = VocabularyManager.Shared;

            vocabManager.SetWord("mytestword", "MyTestReplacement");
            var vocab = vocabManager.GetVocabulary();

            Assert.True(vocab.ContainsKey("mytestword"));
            Assert.Equal("MyTestReplacement", vocab["mytestword"]);

            // Case insensitivity
            Assert.True(vocab.ContainsKey("MYTESTWORD"));

            vocabManager.RemoveWord("mytestword");
            var updatedVocab = vocabManager.GetVocabulary();
            Assert.False(updatedVocab.ContainsKey("mytestword"));
        }
    }
}
