using System;
using Xunit;
using ArnaldoTalk.Core;

namespace ArnaldoTalk.Tests
{
    public class TextEnhancerTests
    {
        [Fact]
        public void TestFillerWordRemovalAndCapitalization()
        {
            var enhancer = TextEnhancer.Shared;
            string raw = "um, hello world. uh, this is like, a test.";
            string cleaned = enhancer.CleanTranscript(raw);
            Assert.Equal("Hello world. This is a test.", cleaned);
        }

        [Fact]
        public void TestCustomVocabularyReplacements()
        {
            var enhancer = TextEnhancer.Shared;
            string raw = "testing arnaldo talk dictation with github and kubernetes";
            string cleaned = enhancer.CleanTranscript(raw);
            Assert.Equal("Testing Arnaldo Talk dictation with GitHub and Kubernetes.", cleaned);
        }

        [Fact]
        public void TestSpokenPunctuationCommands()
        {
            var enhancer = TextEnhancer.Shared;

            string raw1 = "Hello world period How are you question mark";
            string cleaned1 = enhancer.CleanTranscript(raw1);
            Assert.Equal("Hello world. How are you?", cleaned1);

            string raw2 = "Important note colon new line bullet point first item new line bullet point second item";
            string cleaned2 = enhancer.CleanTranscript(raw2);
            Assert.Equal("Important note:\n• First item\n• Second item", cleaned2);

            string raw3 = "Paragraph one full stop new paragraph Paragraph two exclamation point";
            string cleaned3 = enhancer.CleanTranscript(raw3);
            Assert.Equal("Paragraph one.\n\nParagraph two!", cleaned3);
        }

        [Fact]
        public void TestSelfCorrectionEngine()
        {
            var enhancer = TextEnhancer.Shared;

            // 1. "wait no" substitution
            string raw1 = "Send the document to John, wait no, Sarah by tomorrow.";
            string cleaned1 = enhancer.CleanTranscript(raw1);
            Assert.Equal("Send the document to Sarah by tomorrow.", cleaned1);

            // 2. "actually" substitution
            string raw2 = "Let's schedule the call at 3, actually 4 PM.";
            string cleaned2 = enhancer.CleanTranscript(raw2);
            Assert.Equal("Let's schedule the call at 4 PM.", cleaned2);

            // 3. "scratch that" word substitution
            string raw3 = "We should fly to Paris, scratch that, Rome next week.";
            string cleaned3 = enhancer.CleanTranscript(raw3);
            Assert.Equal("We should fly to Rome next week.", cleaned3);

            // 4. "scratch that" sentence deletion
            string raw4 = "I would like some cake. Scratch that. I want some tea.";
            string cleaned4 = enhancer.CleanTranscript(raw4);
            Assert.Equal("I want some tea.", cleaned4);
        }

        [Fact]
        public void TestHebrewSpokenPunctuationAndSelfCorrection()
        {
            var enhancer = TextEnhancer.Shared;

            // 1. Hebrew spoken punctuation
            string rawHebrew = "שלום עולם נקודה מה שלומך סימן שאלה";
            string cleanedHebrew = enhancer.CleanTranscript(rawHebrew);
            Assert.Equal("שלום עולם. מה שלומך?", cleanedHebrew);

            string rawHebrew2 = "הערה חשובה נקודתיים שורה חדשה תודה רבה סימן קריאה";
            string cleanedHebrew2 = enhancer.CleanTranscript(rawHebrew2);
            Assert.Equal("הערה חשובה:\nתודה רבה!", cleanedHebrew2);

            // 2. Hebrew self-correction ("בעצם לא")
            string rawCorrection = "נפגש בשעה שלוש בעצם לא ארבע היום";
            string cleanedCorrection = enhancer.CleanTranscript(rawCorrection);
            Assert.Equal("נפגש בשעה ארבע היום.", cleanedCorrection);

            // 3. Hebrew sentence scratch ("תמחק את זה")
            string rawScratch = "אני רוצה פיצה נקודה תמחק את זה אני רוצה סלט נקודה";
            string cleanedScratch = enhancer.CleanTranscript(rawScratch);
            Assert.Equal("אני רוצה סלט.", cleanedScratch);

            // 4. Hebrew final letter normalization
            string rawFinal = "שלומ לככ";
            string cleanedFinal = enhancer.CleanTranscript(rawFinal);
            Assert.Equal("שלום לכך.", cleanedFinal);
        }

        [Fact]
        public void TestGrammarCorrectionAndAutoPunctuation()
        {
            var enhancer = TextEnhancer.Shared;

            // 1. Automatic question punctuation for single questions
            string q1 = enhancer.CleanTranscript("what time is the meeting");
            Assert.Equal("What time is the meeting?", q1);

            string q2 = enhancer.CleanTranscript("how are you doing today");
            Assert.Equal("How are you doing today?", q2);

            // 2. Multi-sentence question punctuation
            string multi = enhancer.CleanTranscript("hello world period how are you");
            Assert.Equal("Hello world. How are you?", multi);

            // 3. Contractions and pronoun "I"
            string c1 = enhancer.CleanTranscript("dont worry i will be there");
            Assert.Equal("Don't worry I will be there.", c1);

            string c2 = enhancer.CleanTranscript("i cant do this right now");
            Assert.Equal("I can't do this right now.", c2);

            // 4. Stutter word deduplication
            string dedup = enhancer.CleanTranscript("we we need to go");
            Assert.Equal("We need to go.", dedup);

            // 5. Percentages and currency
            string p1 = enhancer.CleanTranscript("twenty-five percent discount for ten dollars");
            Assert.Equal("25% discount for $10.", p1);

            // 6. Bullet points without forced trailing period
            string bullet = enhancer.CleanTranscript("bullet point item one new line bullet point item two");
            Assert.Equal("• Item one\n• Item two", bullet);
        }

        [Fact]
        public void TestFeatureToggleSettings()
        {
            var enhancer = TextEnhancer.Shared;
            string raw = "Hello world period Send to Bob wait no Alice";

            // When toggles are disabled, words must remain literal
            string rawOutput = enhancer.CleanTranscript(
                raw,
                spokenPunctuation: false,
                selfCorrection: false,
                autoPunctuation: false,
                grammarCorrection: false
            );

            Assert.Contains("period", rawOutput);
            Assert.Contains("wait", rawOutput);
            Assert.Contains("Bob", rawOutput);
        }
    }
}
