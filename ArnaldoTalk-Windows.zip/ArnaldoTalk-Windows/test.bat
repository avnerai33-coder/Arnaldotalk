@echo off
echo ==============================================
echo       Running Arnaldo Talk Test Suite
echo ==============================================
echo.

where dotnet >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [.NET Not Found] Please install .NET 8 or 9 SDK:
    echo   winget install Microsoft.DotNet.SDK.8
    pause
    exit /b 1
)

cd /d "%~dp0"
dotnet test ArnaldoTalk.Tests\ArnaldoTalk.Tests.csproj -v normal
pause
