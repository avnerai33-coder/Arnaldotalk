# Arnaldo Talk for Windows PC 🎙️

**Arnaldo Talk for Windows** is an ultra-fast, 100% on-device voice dictation utility for Windows 10 & 11. It provides system-wide speech-to-text with auto-editing, spoken punctuation commands, self-correction, and direct Unicode keystroke injection without clipboard pollution.

---

## Features

- **Global Hotkey (`Ctrl + Win + Space`)**: Press to start dictation anywhere in Windows (Word, Chrome, Slack, Discord, VS Code, Notepad).
- **Floating Glass HUD**: Non-activating, borderless rounded dark pill positioned top-center on your screen. Never steals keyboard focus.
- **Direct Unicode Typing (`SendInput`)**: Inserts characters directly into your active input cursor. Does **not** modify or pollute your Windows Clipboard.
- **100% On-Device Whisper**: Powered by `Whisper.net` using quantized models (`ggml-base.bin`). No cloud subscription or audio sent over the internet.
- **Spoken Punctuation**:
  - *"period"* / *"full stop"* $\rightarrow$ `.`
  - *"comma"* $\rightarrow$ `,`
  - *"question mark"* $\rightarrow$ `?`
  - *"new line"* $\rightarrow$ `\n`
  - *"new paragraph"* $\rightarrow$ `\n\n`
  - *"bullet point"* $\rightarrow$ `\n• `
- **Conversational Self-Correction**:
  - *"Send this to David, wait no, Sarah"* $\rightarrow$ *"Send this to Sarah"*
  - *"Let's meet at 3, actually 4 PM"* $\rightarrow$ *"Let's meet at 4 PM"*
  - *"We should go to Paris, scratch that, Rome"* $\rightarrow$ *"We should go to Rome"*
- **Custom Vocabulary**: Automatically loaded from `%APPDATA%\ArnaldoTalk\vocabulary.json`.

---

## Quick Start (Windows)

### Prerequisites
- Windows 10 (1903+) or Windows 11
- .NET 8 or 9 SDK (install via winget if needed):
  ```powershell
  winget install Microsoft.DotNet.SDK.8
  ```

### 1-Click Run
Double-click `run.bat` or run:
```powershell
dotnet run --project ArnaldoTalk\ArnaldoTalk.csproj -c Release
```

### 1-Click Automated Tests
Double-click `test.bat` or run:
```powershell
dotnet test ArnaldoTalk.Tests\ArnaldoTalk.Tests.csproj
```

### Build Single-File `.exe`
Run `build.ps1` in PowerShell:
```powershell
.\build.ps1
```
The output single-file binary will be generated at `dist\ArnaldoTalk.exe`.

---

## Architecture

| Component | Technology | Purpose |
| :--- | :--- | :--- |
| **UI Shell** | WPF (C# / .NET 8) | Floating top-center HUD window with `WS_EX_NOACTIVATE` |
| **Audio Capture** | `NAudio` (WASAPI) | 16kHz Float32 mono low-latency capture |
| **Speech Engine** | `Whisper.net` + DirectML | On-device local neural speech-to-text |
| **Text Enhancer** | Regex NLP Engine | Punctuation, self-corrections & vocabulary |
| **Keystroke Injection** | Win32 `SendInput(KEYEVENTF_UNICODE)` | Direct Unicode text delivery into active window |
| **Global Trigger** | Win32 `RegisterHotKey` | `Ctrl + Win + Space` |

